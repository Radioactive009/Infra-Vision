
  # Design AI Features Section

  This is a code bundle for Design AI Features Section. The original project is available at https://www.figma.com/design/jx4Xti51zHUW9Q97oH8SLS/Design-AI-Features-Section.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  