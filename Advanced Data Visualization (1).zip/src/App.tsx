import { AdvancedDataVisualization } from "./components/AdvancedDataVisualization";

export default function App() {
  return (
    <div className="size-full">
      <AdvancedDataVisualization />
    </div>
  );
}
